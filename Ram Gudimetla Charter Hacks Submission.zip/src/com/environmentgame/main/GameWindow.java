package com.environmentgame.main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class GameWindow extends JFrame {
	public GameWindow() throws InterruptedException {
		JFrame gameFrame = new JFrame("Replant");
		gameFrame.setBackground(Color.CYAN);
		gameFrame.setTitle("Replant");
	    gameFrame.setResizable(true);
	    gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    gameFrame.setBounds(100, 100, 602,780);
	    ImageIcon tree = new ImageIcon("C:\\Users\\Ram Sai Gudimetla\\OneDrive\\Pictures\\Documents\\TreeB.png");
	    gameFrame.setIconImage(tree.getImage());
	    gameFrame.setVisible(true);
	    JPanel loadingPanel = new JPanel();
		gameFrame.setSize(800, 600);
		loadingPanel.setSize(800, 600);
	    //Text and Image for Label
	    JLabel loadingtext = new JLabel("Replant");
	    JLabel ruletext = new JLabel("Rules and Gameplay:");
	    JLabel rule1 = new JLabel("Use arrow keys to move your blue block around");
	    JLabel rule2 = new JLabel("Collect the yellow blocks (trash) and put it in the bin while dodging the red obstacles");
		loadingtext.setFont(new Font("Verdana", Font.BOLD, 70));
		loadingPanel.add(loadingtext);
		rule1.setVerticalAlignment(SwingConstants.BOTTOM);
		rule1.setHorizontalAlignment(SwingConstants.LEFT);
		rule1.setFont(new Font("Verdana", Font.BOLD, 10));
		rule1.setSize(11, 11);
		rule2.setVerticalAlignment(SwingConstants.BOTTOM);
		rule2.setHorizontalAlignment(SwingConstants.LEFT);
		rule2.setFont(new Font("Verdana", Font.BOLD, 10));
		rule2.setSize(11, 11);
		loadingPanel.add(rule1);
		loadingPanel.add(rule2);
		loadingtext.setForeground(Color.green);
		loadingtext.setAlignmentX(0.5f);
		gameFrame.getContentPane().add(loadingPanel);
		JButton button = new JButton("Click to start game");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				gameFrame.dispose();
				new StartGame();
			}
		});
		loadingPanel.add(button, BorderLayout.SOUTH);
		loadingPanel.setSize(100,100);	
		gameFrame.add(loadingPanel);
		gameFrame.getContentPane().setBackground(Color.GREEN);

		gameFrame.setVisible(true); 
		
	}

		
	}
       