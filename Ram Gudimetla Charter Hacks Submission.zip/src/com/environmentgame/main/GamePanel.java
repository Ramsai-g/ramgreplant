package com.environmentgame.main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JPanel;
import javax.swing.Timer;

public class GamePanel extends JPanel implements ActionListener{

	static final int SCREEN_WIDTH = 1300;
	static final int SCREEN_HEIGHT = 750;
	static final int GAME_UNITS = (SCREEN_WIDTH*SCREEN_HEIGHT)/(1/1);
	static final int DELAY = 175;
	final int x[] = new int[GAME_UNITS];
	final int y[] = new int[GAME_UNITS];
	int treesCollected;
	int treeX;
	int treeY;
	int numOfBullets = 5;
	int bulletX[] = new int[numOfBullets];
	int bulletY[] = new int[numOfBullets];
	char direction = 'R';
	boolean running = false;
	Timer timer;
	Random random;
	String facts[] = {"Lighting accounts for 15% of global electricity use. Switching to LEDs will use 90% less energy and last far longer than with the use of incandescent lights.",
	     	"The EU has banned 8 types of the most common single-use plastics, including plastic cutlery, straws, plates, and cotton buds made with plastic.",
	     	"Agricultural emissions could be reduced by as much as 70% by adopting a vegan diet and 63% by adopting a vegetarian diet.",

	     	"Germany has the best recycling rate in the world followed by Austria, South Korea, and Wales.",

	     	"The Smog Free Project, headed by Daan Roosegaard, is a pioneering technology that removes smog from the air and turns it into jewelry.",

	     	"The world�s indigenous population makes up just 5% of the global population yet protects 80% of global biodiversity.",

	     	"Rainforests are being cut down at the rate of 100 acres per minute.",
	     	
	     	"Around 20% of the world�s total oxygen is produced in the Amazon rainforest, where 1% of tree species sequester 50% of the region�s carbon. The forest has 16,000 different species of trees and is estimated to have nearly 400 billion individual trees.",

	     	"All of this arboreal magnificence sequesters between 90 and 140 billion metric tons of carbon. When we lose forest habitat, that carbon makes its way back into the atmosphere.",

	     	"Despite the fact that Norway is over 6,000 miles from Brazil, the country donated a billion US dollars to help save the Amazon rainforest between 2008 and 2015. In fact, the Norwegians are the biggest benefactor in the world for protecting the tropical rainforests.", "Tropical forests cover less than 7 percent of Earth�s landmass but are home to about 50 percent of all living things on the planet.", "Forests are home to 50 million indigenous people around the world, more than the populations of Tokyo, Mexico City, London, New York City and Cairo combined.", "In response to the first Earth Day in 1970, the U.S. Government created the Clean Air, Clean Water, Endangered Species Acts, and the EPA."};
	
	
	GamePanel(){
		random = new Random();
		this.setPreferredSize(new Dimension(SCREEN_WIDTH,SCREEN_HEIGHT));
		this.setBackground(Color.green);
		this.setFocusable(true);
		this.addKeyListener(new MyKeyAdapter());
		startGame();
	}
	public void startGame() {
		newTree();
		newBullets();
		running = true;
		timer = new Timer(DELAY,this);
		timer.start();
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		draw(g);
	}
	public void draw(Graphics g) {
		
		if(running) {
			/*
			for(int i=0;i<SCREEN_HEIGHT/UNIT_SIZE;i++) {
				g.drawLine(i*UNIT_SIZE, 0, i*UNIT_SIZE, SCREEN_HEIGHT);
				g.drawLine(0, i*UNIT_SIZE, SCREEN_WIDTH, i*UNIT_SIZE);
			}
			*/
			g.setColor(Color.yellow);
			g.fillRect(treeX, treeY, 40,40);
			for(int i = 0; i <5; i++) {
				g.setColor(Color.red);
				g.fillRect(bulletX[i], bulletY[i], 40,40);
			}
			g.setColor(Color.blue);  
			g.fillRect(x[0], y[0], 40,40);	
			int i = 0;
			if(i == 0) {
				g.setColor(new Color(random.nextInt(255),random.nextInt(255),random.nextInt(255)));
			}		
			g.setColor(Color.red);
			g.setFont( new Font("Futura",Font.BOLD, 40));
			FontMetrics metrics = getFontMetrics(g.getFont());
			g.drawString("Score: "+treesCollected, (SCREEN_WIDTH - metrics.stringWidth("Score: "+treesCollected))/2, g.getFont().getSize());
		}
		else {
			gameOver(g);
		}

	}
	public void newTree(){
		treeX = random.nextInt((int)(SCREEN_WIDTH/20))*20;
		treeY = random.nextInt((int)(SCREEN_HEIGHT/ 20))*20;
	}
	public void newBullets(){
		for(int i = 0; i < 5; i++) {
			bulletX[i] = random.nextInt((int)(SCREEN_WIDTH/ 20))*20;
			bulletY[i] = random.nextInt((int)(SCREEN_HEIGHT/ 20))*20;
		}
	}
	public void move(){
  
		switch(direction) {
		case 'U':
			y[0] = y[0] - 20;
			break; 
		case 'D':
			y[0] = y[0] + 20;
			break;
		case 'L':
			x[0] = x[0] -20;
			break;
		case 'R':
			x[0] = x[0] + 20;
			break;
		}
		
	}
	public void checkTree() {
		if((x[0] == treeX) && (y[0] == treeY)) {
			treesCollected++;
			newTree();
			newBullets();
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(running) {
			move();
			checkTree();
			checkCollisions();
			isColliding();
		}
		repaint();
	}
	public void checkCollisions() {
		//checks if head collides with body
		//check if head touches left border
		if(x[0] < -3) {
			running = false;
		}
		//check if head touches right border
		if(x[0] > SCREEN_WIDTH + 150) {
			running = false;
		}
		//check if head touches top border
		if(y[0] < -3) {
			running = false;
		}
		//check if head touches bottom border
		if(y[0] > SCREEN_HEIGHT + 150) {
			running = false;
		}
		
		if(!running) {
			timer.stop();
		}
	}
	public boolean isColliding() {
		boolean collisionX = false;
		boolean collisionY = false;
		for(int i = 0; i < 5; i++) {
			collisionX = x[0] == bulletX[i];
			collisionY = y[0] == bulletY[i];
			if(collisionX && collisionY) {
				running = false;
			}
		}
		return false;
	}
	public void gameOver(Graphics g) {
		//Score
		g.setColor(Color.blue);
		g.setFont( new Font("Verdana",Font.BOLD, 40));
		FontMetrics metrics1 = getFontMetrics(g.getFont());
		g.drawString("Score: "+treesCollected, (SCREEN_WIDTH - metrics1.stringWidth("Score: "+treesCollected))/2, g.getFont().getSize());
		//Game Over text
		g.setColor(Color.red);
		g.setFont( new Font("Times New Roman",Font.BOLD, 15));
		FontMetrics metrics2 = getFontMetrics(g.getFont());
		g.drawString("Game Over", (SCREEN_WIDTH - metrics2.stringWidth("Game Over"))/2, SCREEN_HEIGHT/2);
		int rand = random.nextInt(facts.length);
		g.drawString("fun fact" + facts[rand], (SCREEN_WIDTH - metrics2.stringWidth(facts[rand]))/2, SCREEN_HEIGHT/3);
	}
	public class MyKeyAdapter extends KeyAdapter{
		@Override
		public void keyPressed(KeyEvent e) {
			switch(e.getKeyCode()) {
			case KeyEvent.VK_LEFT:
				if(direction != 'R') {
					direction = 'L';
				}
				break;
			case KeyEvent.VK_RIGHT:
				if(direction != 'L') { 
					direction = 'R';
				}
				break;
			case KeyEvent.VK_UP:
				if(direction != 'D') {
					direction = 'U';
				}
				break;
			case KeyEvent.VK_DOWN:
				if(direction != 'U') {
					direction = 'D';
				}
				break;
			}
		}
	}
}