package com.environmentgame.main;

public class EGmain {

	public static void main(String[] args) throws InterruptedException {
		//GameWindow frame = new GameWindow();
		new GameWindow();
	}

}
