package com.environmentgame.main;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class StartGame{
	JLabel expose = new JLabel("Prototype");
	JFrame coolFrame = new JFrame();
	public StartGame() {
		coolFrame.setTitle("Replant");
	    coolFrame.setResizable(true);
	    coolFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    coolFrame.setBounds(100, 100, 602,780);
	    coolFrame.add(new GamePanel());
	    coolFrame.setVisible(true);
		coolFrame.setResizable(false);
		coolFrame.pack();
		coolFrame.setLocationRelativeTo(null);
		
	    
	}
	
}
