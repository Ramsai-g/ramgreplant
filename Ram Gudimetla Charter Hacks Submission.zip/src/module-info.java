module hackathon {
	requires java.desktop;
}